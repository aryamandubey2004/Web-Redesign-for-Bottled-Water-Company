-----------------------
# README
-----------------------
shree krishna corporation is a static one page website for bisleri distributor.

Credits:
-----------------------
- Twitter Bootstrap http://getbootstrap.com
- jQuery http://jquery.org
- Modernizr https://modernizr.com/
- Sticky.js http://stickyjs.com/
- JQuery easing https://github.com/gdsmith/jquery.easing
- Bootsnav http://bootsnav.danurstrap.com/
- Pexels https://www.pexels.com/
- Unsplash https://unsplash.com/

